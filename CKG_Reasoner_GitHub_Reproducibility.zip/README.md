# CKG Reasoner reproducibility package

Reproduce the retrospective six-cohort evaluation in *Training-Free Clinical Reasoning through Medical Ontologies and Cognitive Mapping*. This package fixes the primary analysis at two clusters for every cohort. The original A and E notebooks used three clusters for their exported secondary analyses. Their core results here use the manuscript's two-cluster protocol.

## Setup

Use Python 3.12. From the repository root:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

The command-line runner loads the frozen package from `reasoner/src`. To run the notebooks interactively, install the package into your Jupyter kernel with `python -m pip install -e ./reasoner` and start from the repository root or the `notebooks` directory.

## Data

The six input snapshots are separate from the repository. The manifest records the public source for each cohort, the local file name, row count, original research archive member, and SHA-256 checksum of the exact analysis input. Public downloads can differ from the frozen CSV in column naming or preprocessing. Exact replication requires the frozen CSVs listed in the manifest.

| Cohort | Records | Source |
|---|---:|---|
| A | 1,000 | [Bangladesh dengue mixed evidence](https://www.kaggle.com/datasets/kawsarahmad/dengue-dataset-bangladesh) |
| B | 1,523 | [Dengue fever hematology](https://doi.org/10.17632/6fsrsk3mb8.2) |
| C | 2,190 | [Bangladesh malaria clinical data](https://doi.org/10.17632/t8n3z7s89h.4) |
| D | 4,569 | [Thailand influenza-like illness](https://doi.org/10.5061/dryad.t7n48) |
| E | 989 | [Dengue detection clinical data](https://www.kaggle.com/datasets/aravind3505/dengue-detection-dataset-clinical-data) |
| F | 1,018 | [Structured dengue clinical and hematological data](https://doi.org/10.17632/673swz9tb4.1) |

Put the exact snapshots in `data/` using the names in [the manifest](data/manifest.json). If you have the original CKG research ZIP, the runner can extract just the six allowlisted CSV entries and verify their checksums.

## Reproduce the results

```bash
python reproduce.py --input-zip /path/to/original-CKG.zip
# If the snapshots are already in data/:
python reproduce.py
# Reproduce two cohorts and run their optional stress tests:
python reproduce.py --cohorts A D --secondary
```

The runner writes `runs/main_results.csv` and per-cohort component-ablation and bootstrap tables. It checks both per-cohort tables against the numerical fixtures in `expected/`. This includes accuracy, balanced accuracy, positive-class F1, MCC, coverage, and ablation partition agreement where applicable. The bootstrap resamples fixed retrospective assignments with their reference labels. The headline run uses random state 42, 20 K-means initializations, and 1,000 bootstrap resamples. The optional secondary cells cover seed and cluster-count sensitivity, knowledge ablations, gate sensitivity, evidence withholding, and the influenza confirmatory-test ablation. The original compatible secondary tables for B, C, D, and F are provided for inspection.

The reasoner package and its bundled knowledge YAMLs are under `reasoner/`. The six notebooks reuse the supplied study code with local paths, cleared outputs, and the uniform primary protocol. Generated results and raw data are ignored by Git. The contextual supervised logistic-regression results and proposed FOL/LLM workflow are outside the scope of this replay.

## Verification

The six-cohort core run was executed with the original research archive. All six component-ablation and bootstrap tables matched their archived reference values. The optional secondary run is provided separately from the verified core run.
