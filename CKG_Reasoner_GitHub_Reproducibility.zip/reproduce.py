"""Run the packaged cohort notebooks and verify their core numerical exports."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / "data/manifest.json").read_text())


def prepare_input(cohort, archive):
    spec = MANIFEST[cohort]
    path = ROOT / "data" / spec["input"]
    if not path.exists() and archive is not None:
        with ZipFile(archive) as source:
            data = source.read(spec["archive_member"])
        if hashlib.sha256(data).hexdigest() != spec["sha256"]:
            raise ValueError(f"Cohort {cohort}: archive input checksum mismatch")
        path.write_bytes(data)
    if not path.exists():
        raise FileNotFoundError(f"Cohort {cohort}: {path.name} required. See data/manifest.json.")
    if hashlib.sha256(path.read_bytes()).hexdigest() != spec["sha256"]:
        raise ValueError(f"Cohort {cohort}: {path.name} differs from the frozen input snapshot")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohorts", nargs="+", choices=list(MANIFEST), default=list(MANIFEST))
    parser.add_argument("--input-zip", type=Path, help="Original CKG research archive")
    parser.add_argument("--secondary", action="store_true", help="Also run the secondary stress tests")
    args = parser.parse_args()
    if args.input_zip is not None:
        args.input_zip = args.input_zip.resolve()
    os.chdir(ROOT)
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ.setdefault(name, "1")
    sys.path.insert(0, str(ROOT / "reasoner/src"))
    import pandas as pd

    summary = []
    for cohort in args.cohorts:
        prepare_input(cohort, args.input_zip)
        notebook = ROOT / "notebooks" / f"{cohort}.ipynb"
        cells = json.loads(notebook.read_text())["cells"]
        scope = {"display": lambda *values: None}
        for number, cell in enumerate(cells, 1):
            if cell["cell_type"] != "code":
                continue
            if "secondary" in cell["metadata"]["tags"] and not args.secondary:
                continue
            exec(compile("".join(cell["source"]), f"{notebook.name}:cell-{number}", "exec"), scope)
        assert len(scope["df"]) == MANIFEST[cohort]["rows"]
        output = ROOT / "runs" / cohort
        for name in ("component_ablation.csv", "bootstrap_95CI.csv"):
            pd.testing.assert_frame_equal(
                pd.read_csv(output / name),
                pd.read_csv(ROOT / "expected" / cohort / name),
                check_dtype=False, rtol=1e-7, atol=1e-9,
            )
        columns = ["accuracy_all", "balanced_accuracy_all", "F1_positive_all", "MCC_all", "coverage"]
        full = scope["component_ablation"].set_index("ablation").loc["Full", columns]
        summary.append({"cohort": cohort, "n": MANIFEST[cohort]["rows"], **full.to_dict()})
        print(f"Cohort {cohort}: core outputs match.")

    path = ROOT / "runs" / "main_results.csv"
    pd.DataFrame(summary).to_csv(path, index=False)
    print(f"Main results: {path.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
